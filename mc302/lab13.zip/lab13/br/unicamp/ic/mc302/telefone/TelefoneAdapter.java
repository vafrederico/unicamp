package br.unicamp.ic.mc302.telefone;

public class TelefoneAdapter implements TelefoneListener {

	public void telefoneTocou(TelefoneEvent e) {}
	
	public void telefoneAtendido(TelefoneEvent e) {}

}
