package br.unicamp.ic.mc302.documento;

public class Carta extends Documento {

	private String transporte;

	public void anexar() {
		System.out.println("Anexa � Carta.");
	}
}