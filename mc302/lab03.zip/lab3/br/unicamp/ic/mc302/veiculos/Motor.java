package br.unicamp.ic.mc302.veiculos;

public class Motor {
	
	private boolean ligado = false;
	
	public void ligar(){
		ligado = true;
		
	}
	
	public void desligar(){
		ligado = false;
	}
	
}
