package onibus;

public class Assento {
	
	private boolean ocupado = false;
	
	public boolean ocupado(){
		return this.ocupado;
	}
	
	public void setOcupado(){
		this.ocupado = true;
	}
}
