<?php
	
	$xml = simplexml_load_file("person.xml");

$host = "sql2.lab.ic.unicamp.br";
$user = "mc536in20";
$password = "ohuigaet";
$database = "mc536indb20";

	$conn = mysql_connect($host,$user,$password);
	$db = mysql_select_db($database, $conn);
	foreach ($xml as $person) {
		
		$uri = utf8_decode($person['uri']);
		$nome = utf8_decode($person['name']);
		$natal = utf8_decode($person['hometown']);

		$query = "INSERT INTO `PESSOAS` VALUES ('$uri', '$nome', '$natal')";
		mysql_query($query);

	}



	$xml = simplexml_load_file("knows.xml");

	foreach ($xml as $knows) {
		
		$person = utf8_decode($knows['person']);
		$colleague = utf8_decode($knows['colleague']);
		$query = "INSERT INTO `RELACAO` (USUARIO, PESSOA_ALVO, TIPO_BLOQUEIO) VALUES ('$person', '$colleague', 1)";
		mysql_query($query);
		
	}
	


	$xml = simplexml_load_file("likesMusic.xml");

	foreach ($xml as $likes) {
		$person = utf8_decode($likes['person']);
		$colleague = utf8_decode($likes['colleague']);
		$pais = "";
		$genero = "";
		$nomeArtistico = "";
		$rating = utf8_decode($likes['rating']);
		$query = "INSERT INTO ARTISTAS_MUSICAIS VALUES ('$colleague', '$pais','$genero','$nomeArtistico')";
		mysql_query($query);

		$query = "INSERT INTO `AVALIACOES` VALUES ('$person', '$colleague', $rating)";
		mysql_query($query);
		
	}
	
	mysql_close($conn);

?>