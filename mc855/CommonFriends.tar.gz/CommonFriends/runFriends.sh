#!/bin/sh
echo "Running...."
hadoop jar FriendsJob.jar FriendsJob /input1 /$1